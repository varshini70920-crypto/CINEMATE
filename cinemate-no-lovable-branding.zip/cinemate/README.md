# Cinemate

Cinemate is a TV-inspired movie discovery and story recap app built with TanStack Start, React, and TypeScript.

## Run with Bun

Install [Bun](https://bun.sh), then run these commands from this folder:

```sh
bun install
bun run dev
```

Open the local URL printed in your terminal. To create a production build, run `bun run build`.

## AI story recaps

Story Recap requires a server-side AI access key. Configure the environment variable expected by `src/lib/recap.functions.ts` before starting the server. The rest of the app can run without the key, but recap requests will show a setup message.

## Project stack

- TanStack Start and TanStack Router
- React and TypeScript
- Tailwind CSS
