# Project notes

- This is the Cinemate application.
- Use Bun for installing dependencies and running scripts.
- Keep the Fire TV-inspired interface and Cinemate branding consistent.
