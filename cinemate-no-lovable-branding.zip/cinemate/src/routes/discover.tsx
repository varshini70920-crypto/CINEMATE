import { createFileRoute } from "@tanstack/react-router";
import { TITLES, LANGUAGES, GENRES } from "@/lib/data";
import { store, useStore, type Filters } from "@/lib/store";
import { PosterCard } from "@/components/PosterCard";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/discover")({
  head: () => ({
    meta: [
      { title: "Discover — Cinemate" },
      { name: "description", content: "Filter by language, genre, length and type to find your next watch." },
      { property: "og:title", content: "Discover — Cinemate" },
      { property: "og:description", content: "Filter by language, genre, length and type." },
    ],
  }),
  component: Discover,
});

const TIMES = [30, 60, 120];

function Discover() {
  const f = useStore((s) => s.filters);
  const set = (p: Partial<Filters>) => store.setFilters({ ...f, ...p });
  const list = TITLES.filter(
    (t) =>
      (!f.language || t.language === f.language) &&
      (!f.genre || t.genre === f.genre) &&
      (!f.type || t.type === f.type) &&
      (!f.maxMinutes || t.minutes <= f.maxMinutes),
  );
  return (
    <div className="px-14 pt-8">
      <h1 className="text-5xl font-extrabold">Discover</h1>
      <div className="mt-6 space-y-4">
        <ChipRow label="Language" opts={LANGUAGES} val={f.language} on={(v) => set({ language: v })} />
        <ChipRow label="Genre" opts={GENRES} val={f.genre} on={(v) => set({ genre: v })} />
        <ChipRow label="Time" opts={TIMES.map((m) => `Under ${m}m`)} val={f.maxMinutes ? `Under ${f.maxMinutes}m` : undefined} on={(v) => set({ maxMinutes: v ? Number(v.match(/\d+/)![0]) : undefined })} />
        <ChipRow label="Type" opts={["Movie", "Show"]} val={f.type} on={(v) => set({ type: v as Filters["type"] })} />
      </div>
      <div className="mt-8 text-muted-foreground">{list.length} matches</div>
      <div className="mt-3 flex flex-wrap gap-5">
        {list.map((t) => (
          <PosterCard key={t.id} t={t} />
        ))}
        {!list.length && <div className="text-xl text-muted-foreground">Nothing matches — try removing a filter.</div>}
      </div>
    </div>
  );
}

function ChipRow({ label, opts, val, on }: { label: string; opts: string[]; val?: string | undefined; on: (v?: string) => void }) {
  return (
    <div className="flex items-center gap-3">
      <div className="w-28 text-muted-foreground">{label}</div>
      {["Any", ...opts].map((o) => {
        const active = o === "Any" ? !val : o === val;
        return (
          <button
            key={o}
            data-focusable
            onClick={() => on(o === "Any" ? undefined : o)}
            className={cn("tv-focus rounded-full px-5 py-2 text-lg", active ? "bg-primary text-primary-foreground" : "bg-secondary")}
          >
            {o}
          </button>
        );
      })}
    </div>
  );
}
