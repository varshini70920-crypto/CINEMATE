import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Play, Sparkles, Info } from "lucide-react";
import { CONTINUE, TITLES, type Title } from "@/lib/data";
import { PosterCard } from "@/components/PosterCard";
import { TvButton } from "@/components/tv";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Cinemate — Home" },
      { name: "description", content: "Continue watching, discover new picks and manage your Fire TV with Cinemate." },
      { property: "og:title", content: "Cinemate — Home" },
      { property: "og:description", content: "A smarter Fire TV home with recaps, storage manager and voice assistant." },
    ],
  }),
  component: Home,
});

const BLURBS: Record<string, string> = {
  "night-signal": "A detective chases late-night radio broadcasts that seem to know her secrets.",
  "monsoon-cafe": "A rainy Chennai café, a stubborn owner and a critic with a secret.",
  "orbit-9": "Cut off from Earth, a space station crew discovers a saboteur among them.",
};

function Home() {
  const nav = useNavigate();
  const [picked, setPicked] = useState<Title | null>(null);
  const [h, setH] = useState(0);
  const heroBtn = useRef<HTMLButtonElement>(null);
  useEffect(() => heroBtn.current?.focus(), []);
  useEffect(() => {
    const id = setInterval(() => setH((x) => (x + 1) % CONTINUE.length), 9000);
    return () => clearInterval(id);
  }, []);
  const hero = CONTINUE[h]!;

  const rows: [string, Title[]][] = [
    ["Trending Now", TITLES.filter((t) => !t.progress)],
    ["Comedy Picks", TITLES.filter((t) => t.genre === "Comedy")],
    ["Tamil Favourites", TITLES.filter((t) => t.language === "Tamil")],
  ];

  return (
    <div>
      <section className="relative -mt-24 h-[78vh] min-h-[520px] overflow-hidden">
        {CONTINUE.map((t, i) => (
          <img
            key={t.id}
            src={t.image}
            alt={i === h ? t.title : ""}
            className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-1000 ${i === h ? "opacity-100" : "opacity-0"}`}
          />
        ))}
        <div className="billboard-fade absolute inset-0" />
        <div className="relative flex h-full max-w-2xl flex-col justify-end px-14 pb-16">
          <div className="mb-3 text-sm font-semibold uppercase tracking-[0.3em] text-accent">Featured {hero.type}</div>
          <h1 className="text-7xl font-extrabold drop-shadow-lg">{hero.title}</h1>
          <div className="mt-3 flex gap-3 text-muted-foreground">
            <span>{hero.year}</span>·<span>{hero.genre}</span>·<span>{hero.language}</span>·<span className="rounded border border-border px-1.5 text-sm">U/A 13+</span>
          </div>
          <p className="mt-4 text-xl text-foreground/85">{BLURBS[hero.id]}</p>
          <div className="mt-7 flex gap-3">
            <TvButton ref={heroBtn} variant="primary" onClick={() => setPicked(hero)}>
              <Play className="h-5 w-5 fill-current" /> Resume
            </TvButton>
            <Link to="/recap/$id" params={{ id: hero.id }} data-focusable className="tv-focus inline-flex items-center gap-2 rounded-xl bg-secondary/80 px-6 py-3.5 text-lg font-semibold backdrop-blur">
              <Sparkles className="h-5 w-5" /> Quick Recap
            </Link>
            <TvButton variant="ghost" onClick={() => nav({ to: "/watch/$id", params: { id: hero.id } })} aria-label="More info">
              <Info className="h-5 w-5" />
            </TvButton>
          </div>
          <div className="mt-8 flex gap-2">
            {CONTINUE.map((t, i) => (
              <span key={t.id} className={`h-1.5 rounded-full transition-all ${i === h ? "w-10 bg-foreground" : "w-4 bg-foreground/30"}`} />
            ))}
          </div>
        </div>
      </section>

      <div className="relative z-10 -mt-6 px-14">
        <Row title="Continue Watching">
          {CONTINUE.map((t) => (
            <PosterCard key={t.id} t={t} wide onSelect={() => setPicked(t)} />
          ))}
        </Row>
        {rows.map(([title, list]) => (
          <Row key={title} title={title}>
            {list.map((t) => (
              <PosterCard key={t.id} t={t} onSelect={() => setPicked(t)} />
            ))}
          </Row>
        ))}
      </div>

      {picked && <TitleDialog t={picked} onClose={() => setPicked(null)} />}
    </div>
  );
}

function Row({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mt-6">
      <h2 className="mb-1 text-2xl font-semibold">{title}</h2>
      <div className="-mx-4 flex gap-4 overflow-x-auto px-4 py-5">{children}</div>
    </section>
  );
}

function TitleDialog({ t, onClose }: { t: Title; onClose: () => void }) {
  const ref = useRef<HTMLAnchorElement>(null);
  useEffect(() => {
    ref.current?.focus();
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [onClose]);
  return (
    <div data-nav-scope className="fixed inset-0 z-30 flex items-center justify-center bg-background/80 backdrop-blur">
      <div className="glass w-[720px] overflow-hidden rounded-3xl">
        <div className="relative h-56">
          <img src={t.image} alt={t.title} className="h-full w-full object-cover" />
          <div className="hero-fade absolute inset-0" />
        </div>
        <div className="p-10 pt-2">
          <h2 className="text-4xl font-bold">{t.title}</h2>
          <p className="mt-2 text-lg text-muted-foreground">
            {t.progress ? `${t.episode} · ${t.timestamp} · ${Math.round(t.progress * 100)}% watched` : `${t.type} · ${t.genre} · ${t.language} · ${t.minutes} min · ${t.year}`}
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link ref={ref} to="/watch/$id" params={{ id: t.id }} data-focusable className="tv-focus inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3.5 text-lg font-semibold text-primary-foreground">
              <Play className="h-5 w-5 fill-current" /> {t.progress ? "Continue Watching" : "Watch Now"}
            </Link>
            <Link to="/recap/$id" params={{ id: t.id }} data-focusable className="tv-focus inline-flex items-center gap-2 rounded-xl bg-secondary px-6 py-3.5 text-lg font-semibold">
              <Sparkles className="h-5 w-5" /> {t.progress ? "Quick Recap" : "Story Summary"}
            </Link>
            <TvButton variant="ghost" onClick={onClose}>Close</TvButton>
          </div>
        </div>
      </div>
    </div>
  );
}
