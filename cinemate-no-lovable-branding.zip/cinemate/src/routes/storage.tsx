import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Trash2, Eraser, Sparkles, HardDrive, CheckCircle2 } from "lucide-react";
import { store, useStore, usage, suggestions, fmt, TOTAL_GB } from "@/lib/store";
import { TvButton } from "@/components/tv";

export const Route = createFileRoute("/storage")({
  head: () => ({
    meta: [
      { title: "Storage Manager — Cinemate" },
      { name: "description", content: "See what's using space on your Fire TV and free it up in one click." },
      { property: "og:title", content: "Storage Manager — Cinemate" },
      { property: "og:description", content: "See what's using space and free it up in one click." },
    ],
  }),
  component: Storage,
});

type Pending = { title: string; body: string; run: () => void };

function Storage() {
  const s = useStore((x) => x);
  const u = usage(s);
  const apps = [...s.apps].sort((a, b) => b.appGB + b.cacheGB - (a.appGB + a.cacheGB));
  const sug = suggestions(s);
  const total = sug.reduce((n, x) => n + x.gb, 0);
  const [pending, setPending] = useState<Pending | null>(null);
  const [toast, setToast] = useState("");
  const firstRef = useRef<HTMLButtonElement>(null);
  useEffect(() => firstRef.current?.focus(), []);

  const confirm = (p: Pending) => setPending(p);
  const done = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(""), 2500);
  };

  const segs = [
    { label: "Apps", gb: u.apps, cls: "bg-chart-1" },
    { label: "Cache & downloads", gb: u.cache, cls: "bg-chart-2" },
    { label: "System", gb: u.system, cls: "bg-chart-3" },
  ];

  return (
    <div className="px-14 pt-8">
      <h1 className="flex items-center gap-3 text-5xl font-extrabold">
        <HardDrive className="h-10 w-10 text-primary" /> Storage Manager
      </h1>

      <section className="glass mt-6 rounded-3xl p-8">
        <div className="flex items-end justify-between">
          <div>
            <div className="font-display text-5xl font-bold">{fmt(u.free)} <span className="text-2xl text-muted-foreground">free</span></div>
            <div className="mt-1 text-lg text-muted-foreground">{fmt(u.used)} used of {TOTAL_GB} GB</div>
          </div>
          {s.freedGB > 0 && <div className="text-lg text-success">Freed {fmt(s.freedGB)} this session</div>}
        </div>
        <div className="mt-6 flex h-6 overflow-hidden rounded-full bg-foreground/10">
          {segs.map((g) => (
            <div key={g.label} className={`${g.cls} transition-all duration-700`} style={{ width: `${(g.gb / TOTAL_GB) * 100}%` }} />
          ))}
        </div>
        <div className="mt-4 flex gap-8">
          {segs.map((g) => (
            <div key={g.label} className="flex items-center gap-2 text-lg">
              <span className={`h-3.5 w-3.5 rounded-full ${g.cls}`} /> {g.label} <span className="text-muted-foreground">{fmt(g.gb)}</span>
            </div>
          ))}
          <div className="flex items-center gap-2 text-lg">
            <span className="h-3.5 w-3.5 rounded-full bg-foreground/10" /> Free <span className="text-muted-foreground">{fmt(u.free)}</span>
          </div>
        </div>
      </section>

      <div className="mt-8 grid grid-cols-[1fr_1fr] gap-8">
        <section>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-2xl font-semibold"><Sparkles className="h-6 w-6 text-primary" /> Smart cleanup</h2>
            <TvButton
              ref={firstRef}
              variant="primary"
              disabled={!sug.length}
              onClick={() =>
                confirm({
                  title: "Clear all suggested?",
                  body: `This removes ${sug.length} items and frees about ${fmt(total)}. Uninstalled apps can be reinstalled later.`,
                  run: () => done(`Freed ${fmt(store.clearAllSuggested())}`),
                })
              }
            >
              Clear All Suggested · {fmt(total)}
            </TvButton>
          </div>
          <div className="space-y-3">
            {sug.map((x) => (
              <div key={x.id} className="glass flex items-center gap-4 rounded-2xl p-4">
                <div className="flex-1">
                  <div className="text-lg font-semibold">{x.label}</div>
                  <div className="text-muted-foreground">{x.detail}</div>
                </div>
                <div className="w-20 text-right font-semibold">{fmt(x.gb)}</div>
                <TvButton
                  variant={x.kind === "unused" ? "danger" : "secondary"}
                  className="px-4 py-2.5 text-base"
                  onClick={() =>
                    confirm({
                      title: x.label + "?",
                      body: `This frees ${fmt(x.gb)}.`,
                      run: () => {
                        if (x.kind === "unused") store.uninstall(x.appId!);
                        else if (x.kind === "cache") store.clearCache(x.appId!);
                        else store.clearTemp();
                        done(`Freed ${fmt(x.gb)}`);
                      },
                    })
                  }
                >
                  {x.kind === "unused" ? "Uninstall" : "Clear"}
                </TvButton>
              </div>
            ))}
            {!sug.length && (
              <div className="glass flex items-center gap-3 rounded-2xl p-6 text-lg">
                <CheckCircle2 className="text-success" /> All clean — nothing to suggest.
              </div>
            )}
          </div>
        </section>

        <section>
          <h2 className="mb-4 text-2xl font-semibold">Apps by size</h2>
          <div className="space-y-3">
            {apps.map((a) => (
              <div key={a.id} className="glass flex items-center gap-4 rounded-2xl p-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl font-display text-xl font-bold" style={{ background: a.color }}>
                  {a.letter}
                </div>
                <div className="flex-1">
                  <div className="text-lg font-semibold">{a.name} – {fmt(a.appGB + a.cacheGB)}</div>
                  <div className="text-sm text-muted-foreground">
                    App {fmt(a.appGB)} · Cache {fmt(a.cacheGB)} · {a.lastOpenedDays === 0 ? "Used today" : `Opened ${a.lastOpenedDays}d ago`}
                  </div>
                </div>
                <TvButton className="px-3 py-2.5 text-base" disabled={!a.cacheGB} aria-label={`Clear ${a.name} cache`}
                  onClick={() => confirm({ title: `Clear ${a.name} cache?`, body: `Frees ${fmt(a.cacheGB)}. You'll stay signed in.`, run: () => { const g = a.cacheGB; store.clearCache(a.id); done(`Freed ${fmt(g)}`); } })}>
                  <Eraser className="h-5 w-5" />
                </TvButton>
                <TvButton variant="danger" className="px-3 py-2.5 text-base" aria-label={`Uninstall ${a.name}`}
                  onClick={() => confirm({ title: `Uninstall ${a.name}?`, body: `Frees ${fmt(a.appGB + a.cacheGB)}. Downloads in this app will be removed.`, run: () => { const g = a.appGB + a.cacheGB; store.uninstall(a.id); done(`Freed ${fmt(g)}`); } })}>
                  <Trash2 className="h-5 w-5" />
                </TvButton>
              </div>
            ))}
          </div>
        </section>
      </div>

      {pending && <Confirm p={pending} onClose={() => setPending(null)} />}
      {toast && <div className="fixed left-1/2 top-8 z-50 -translate-x-1/2 rounded-full bg-success px-6 py-3 text-lg font-semibold text-primary-foreground">{toast}</div>}
    </div>
  );
}

function Confirm({ p, onClose }: { p: Pending; onClose: () => void }) {
  const cancel = useRef<HTMLButtonElement>(null);
  const prev = useRef<Element | null>(null);
  useEffect(() => {
    prev.current = document.activeElement;
    cancel.current?.focus();
    return () => (prev.current as HTMLElement | null)?.focus?.();
  }, []);
  return (
    <div data-nav-scope className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur">
      <div className="glass w-[560px] rounded-3xl p-10">
        <h2 className="text-3xl font-bold">{p.title}</h2>
        <p className="mt-3 text-lg text-muted-foreground">{p.body}</p>
        <div className="mt-8 flex gap-3">
          <TvButton ref={cancel} onClick={onClose}>Cancel</TvButton>
          <TvButton variant="danger" onClick={() => { p.run(); onClose(); }}>Yes, delete</TvButton>
        </div>
      </div>
    </div>
  );
}
