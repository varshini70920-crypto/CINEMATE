import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { Play, RotateCcw, FileText, Clapperboard, ShieldCheck, Volume2, Search, Sparkles, Square } from "lucide-react";
import { CONTINUE, TITLES, poster, slugify, unslug, type Title } from "@/lib/data";
import { summarizeTitle } from "@/lib/recap.functions";
import { speakSoft, stopSpeaking } from "@/lib/voice";
import { TvButton } from "@/components/tv";

export const Route = createFileRoute("/recap/$id")({
  loader: ({ params }) => {
    const t = TITLES.find((x) => x.id === params.id) ?? null;
    return { t, name: t?.title ?? unslug(params.id) };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `Recap: ${loaderData?.name ?? ""} — Cinemate` },
      { name: "description", content: "Spoiler-safe story summary of any movie or show." },
      { property: "og:title", content: `Story Recap — ${loaderData?.name ?? ""}` },
      { property: "og:description", content: "Spoiler-safe story summary of any movie or show." },
    ],
  }),
  component: Recap,
});

type View = {
  title: string;
  subtitle: string;
  intro: string;
  body: string[];
  scenes: string[];
  characters: { name: string; role: string }[];
  image?: string | undefined;
  hue: number;
};

function fromLocal(t: Title): View {
  return {
    title: t.title,
    subtitle: `${t.genre} · ${t.language} · ${t.year}`,
    intro: t.recap![0]!,
    body: t.recap!.slice(1),
    scenes: t.scenes ?? [],
    characters: t.characters ?? [],
    image: t.image,
    hue: t.hue,
  };
}

function Recap() {
  const { t, name } = Route.useLoaderData();
  const local = t?.recap ? t : null;

  const q = useQuery({
    queryKey: ["recap", name],
    enabled: !local,
    staleTime: Infinity,
    retry: false,
    queryFn: () =>
      summarizeTitle({
        data: {
          name,
          catalog: !!t,
          context: t ? `${t.type}, ${t.genre}, ${t.language}, ${t.year}, ${t.minutes} min. ${t.blurb ?? ""}` : undefined,
        },
      }),
  });

  let view: View | null = local ? fromLocal(local) : null;
  if (!view && q.data) {
    view = {
      title: q.data.found ? q.data.title : name,
      subtitle: [q.data.genre, q.data.year].filter(Boolean).join(" · "),
      intro: q.data.tagline || `The story of ${q.data.title}`,
      body: q.data.summary,
      scenes: q.data.scenes,
      characters: q.data.characters,
      image: t?.image,
      hue: t?.hue ?? 220,
    };
  }

  return (
    <div className="px-14 pt-6">
      <RecapSearch />
      {view ? (
        <RecapBody key={name} v={view} t={t} />
      ) : q.isError ? (
        <div className="glass mt-8 rounded-3xl p-10">
          <h1 className="text-4xl font-bold">{name}</h1>
          <p className="mt-3 text-xl text-muted-foreground">{(q.error as Error).message}</p>
          <TvButton variant="primary" className="mt-6" onClick={() => q.refetch()}>Try again</TvButton>
        </div>
      ) : (
        <RecapLoading name={name} image={t?.image} />
      )}
      {view && q.data && !q.data.found && (
        <p className="mt-4 text-muted-foreground">I couldn't find much about “{name}” — check the spelling and try again.</p>
      )}
    </div>
  );
}

function RecapSearch() {
  const nav = useNavigate();
  const [v, setV] = useState("");
  return (
    <form
      className="flex max-w-2xl gap-3"
      onSubmit={(e) => {
        e.preventDefault();
        if (v.trim()) nav({ to: "/recap/$id", params: { id: slugify(v) } });
        setV("");
      }}
    >
      <div className="tv-input flex flex-1 items-center gap-3 rounded-full px-5">
        <Search className="h-5 w-5 text-muted-foreground" />
        <input
          data-focusable
          value={v}
          onChange={(e) => setV(e.target.value)}
          placeholder="Summarise any movie or show… e.g. Inception, Jailer"
          className="h-12 w-full bg-transparent text-lg outline-none"
        />
      </div>
      <TvButton variant="primary" type="submit" className="rounded-full">
        <Sparkles className="h-5 w-5" /> Summarise
      </TvButton>
    </form>
  );
}

function RecapLoading({ name, image }: { name: string; image?: string | undefined }) {
  return (
    <div className="relative mt-8 aspect-[21/8] overflow-hidden rounded-3xl bg-card">
      {image && <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" />}
      <div className="hero-fade absolute inset-0" />
      <div className="relative flex h-full flex-col justify-end p-10">
        <div className="flex items-center gap-2 text-sm uppercase tracking-[0.3em] text-accent">
          <Sparkles className="h-4 w-4 animate-pulse" /> Writing your recap
        </div>
        <h1 className="mt-2 text-5xl font-extrabold">{name}</h1>
        <div className="mt-6 space-y-3">
          <div className="shimmer h-5 w-3/4 rounded-full" />
          <div className="shimmer h-5 w-2/3 rounded-full" />
          <div className="shimmer h-5 w-1/2 rounded-full" />
        </div>
      </div>
    </div>
  );
}

function RecapBody({ v, t }: { v: View; t: Title | null }) {
  const [mode, setMode] = useState<"text" | "visual">("text");
  const [speaking, setSpeaking] = useState(false);
  const first = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    first.current?.focus();
    return () => stopSpeaking();
  }, []);
  const hasProgress = !!t?.progress;

  return (
    <div className="mt-6 grid grid-cols-[minmax(0,1fr)_320px] gap-8">
      <div>
        <div className="relative overflow-hidden rounded-3xl">
          {v.image ? (
            <img src={v.image} alt={v.title} className="h-64 w-full object-cover" />
          ) : (
            <div className="h-64 w-full" style={{ background: poster(v.hue) }} />
          )}
          <div className="hero-fade absolute inset-0" />
          <div className="absolute bottom-0 left-0 p-8">
            <div className="flex items-center gap-2 text-sm uppercase tracking-[0.3em] text-accent">
              <ShieldCheck className="h-4 w-4" /> Spoiler-safe · AI recap
            </div>
            <h1 className="mt-1 text-5xl font-extrabold">{v.title}</h1>
            <div className="mt-1 text-lg text-muted-foreground">{v.subtitle}</div>
          </div>
        </div>

        <div className="mt-6 flex gap-3">
          <TvButton ref={first} variant={mode === "text" ? "primary" : "secondary"} onClick={() => setMode("text")}>
            <FileText className="h-5 w-5" /> Text Recap
          </TvButton>
          <TvButton variant={mode === "visual" ? "primary" : "secondary"} onClick={() => setMode("visual")}>
            <Clapperboard className="h-5 w-5" /> Visual Recap
          </TvButton>
          <TvButton
            variant="ghost"
            onClick={() => {
              if (speaking) {
                stopSpeaking();
                setSpeaking(false);
              } else {
                speakSoft([v.intro, ...v.body].join(" "));
                setSpeaking(true);
              }
            }}
          >
            {speaking ? <Square className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />} {speaking ? "Stop" : "Read aloud"}
          </TvButton>
        </div>

        <div className="mt-6">
          {mode === "text" ? (
            <div className="glass rounded-3xl p-8">
              <p className="font-display text-2xl italic text-primary">{v.intro}</p>
              <div className="mt-4 space-y-4 text-xl leading-relaxed">
                {v.body.map((p, i) => <p key={i}>{p}</p>)}
              </div>
            </div>
          ) : (
            <VisualRecap scenes={v.scenes} image={v.image} hue={v.hue} />
          )}
        </div>

        {v.characters.length > 0 && (
          <>
            <h2 className="mb-4 mt-10 text-2xl font-semibold">Characters</h2>
            <div className="flex gap-4 overflow-x-auto py-2">
              {v.characters.map((c, i) => (
                <div key={c.name} data-focusable tabIndex={0} className="tv-focus glass flex w-64 shrink-0 items-center gap-4 rounded-2xl p-4">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full font-display text-xl font-bold" style={{ background: poster(v.hue + i * 50) }}>
                    {c.name[0]}
                  </div>
                  <div>
                    <div className="font-semibold">{c.name}</div>
                    <div className="text-sm text-muted-foreground">{c.role}</div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      <aside className="glass h-fit rounded-3xl p-8">
        {hasProgress && t ? (
          <>
            <div className="text-sm uppercase tracking-widest text-muted-foreground">You left off at</div>
            <div className="mt-2 text-xl font-semibold">{t.episode}</div>
            <div className="mt-1 text-lg text-muted-foreground">{t.timestamp}</div>
            <div className="mt-5 flex items-center gap-3">
              <div className="h-2.5 flex-1 rounded-full bg-foreground/15">
                <div className="h-full rounded-full bg-primary" style={{ width: `${t.progress! * 100}%` }} />
              </div>
              <span className="font-semibold">{Math.round(t.progress! * 100)}%</span>
            </div>
            <div className="mt-8 flex flex-col gap-3">
              <Link to="/watch/$id" params={{ id: t.id }} data-focusable className="tv-focus flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-4 text-lg font-semibold text-primary-foreground">
                <Play className="h-5 w-5" /> Continue Watching
              </Link>
              <Link to="/watch/$id" params={{ id: t.id }} search={{ rewind: 1 } as any} data-focusable className="tv-focus flex items-center justify-center gap-2 rounded-xl bg-secondary px-6 py-4 text-lg font-semibold">
                <RotateCcw className="h-5 w-5" /> Replay Last Scene (−2 min)
              </Link>
            </div>
          </>
        ) : t ? (
          <Link to="/watch/$id" params={{ id: t.id }} data-focusable className="tv-focus flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-4 text-lg font-semibold text-primary-foreground">
            <Play className="h-5 w-5" /> Watch now
          </Link>
        ) : (
          <div className="text-muted-foreground">Not in your library yet — summary written by Cinemate AI.</div>
        )}
        <div className="mt-8 border-t border-border pt-5">
          <div className="mb-3 text-sm uppercase tracking-widest text-muted-foreground">More recaps</div>
          <div className="grid grid-cols-2 gap-3">
            {[...CONTINUE, ...TITLES.filter((x) => !x.progress)]
              .filter((x) => x.id !== t?.id)
              .slice(0, 6)
              .map((x) => (
                <Link key={x.id} to="/recap/$id" params={{ id: x.id }} data-focusable className="tv-focus overflow-hidden rounded-xl bg-secondary">
                  <img src={x.image} alt={x.title} loading="lazy" className="h-20 w-full object-cover" />
                  <div className="truncate px-3 py-2 text-sm font-medium">{x.title}</div>
                </Link>
              ))}
          </div>
        </div>
      </aside>
    </div>
  );
}

function VisualRecap({ scenes, image, hue }: { scenes: string[]; image?: string | undefined; hue: number }) {
  const [i, setI] = useState(0);
  useEffect(() => {
    if (!scenes.length) return;
    const id = setInterval(() => setI((x) => (x + 1) % scenes.length), 6000);
    return () => clearInterval(id);
  }, [scenes.length]);
  if (!scenes.length) return null;
  const pos = ["center", "left", "right", "top", "bottom"][i % 5];
  return (
    <div className="relative aspect-video overflow-hidden rounded-3xl">
      {image ? (
        <img key={i} src={image} alt="" className="kenburns absolute inset-0 h-full w-full object-cover" style={{ objectPosition: pos }} />
      ) : (
        <div key={i} className="kenburns absolute inset-0" style={{ background: poster(hue + i * 25) }} />
      )}
      <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-background/90 to-transparent p-8">
        <div className="text-sm uppercase tracking-widest text-accent">Scene {i + 1} of {scenes.length}</div>
        <div className="font-display text-3xl font-bold">{scenes[i]}</div>
        <div className="mt-4 flex gap-1.5">
          {scenes.map((_, k) => (
            <div key={k} className={`h-1.5 flex-1 rounded-full ${k <= i ? "bg-primary" : "bg-foreground/20"}`} />
          ))}
        </div>
      </div>
    </div>
  );
}
