import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { TITLES } from "@/lib/data";

export const Route = createFileRoute("/watch/$id")({
  loader: ({ params, location }) => {
    const t = TITLES.find((x) => x.id === params.id);
    if (!t) throw notFound();
    return { t, rewind: (location.search as any)?.rewind === 1 || (location.search as any)?.rewind === "1" };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `Watching ${loaderData?.t.title ?? ""} — Cinemate` },
      { name: "description", content: "Resume playback on Cinemate." },
      { property: "og:title", content: `Watching ${loaderData?.t.title ?? ""}` },
      { property: "og:description", content: "Resume playback on Cinemate." },
    ],
  }),
  component: Watch,
});

function Watch() {
  const { t, rewind } = Route.useLoaderData();
  const start = (t.progress ?? 0) - (rewind ? 2 / t.minutes : 0);
  const [p, setP] = useState(start);
  useEffect(() => {
    const i = setInterval(() => setP((x) => Math.min(1, x + 0.002)), 500);
    return () => clearInterval(i);
  }, []);
  return (
    <div className="px-14">
      <div className="relative mt-8 flex aspect-video items-end overflow-hidden rounded-3xl p-10" >
        <img src={t.image} alt={t.title} className="kenburns absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
        <div className="relative w-full">
          <div className="text-lg text-muted-foreground">{rewind ? "Replaying last scene (−2 min)" : "Resuming"} · {t.episode ?? `${t.genre} · ${t.year}`}</div>
          <h1 className="text-5xl font-bold">{t.title}</h1>
          <div className="mt-5 h-2 w-full rounded-full bg-foreground/20">
            <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${p * 100}%` }} />
          </div>
          <Link to="/" data-focusable autoFocus className="tv-focus mt-6 inline-flex rounded-xl bg-secondary px-6 py-3 text-lg font-semibold">
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
