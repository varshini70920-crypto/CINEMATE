import { type Title } from "@/lib/data";

export function PosterCard({ t, onSelect, wide }: { t: Title; onSelect?: () => void; wide?: boolean }) {
  return (
    <button
      data-focusable
      onClick={onSelect}
      className={`tile-focus group relative shrink-0 overflow-hidden rounded-xl bg-card text-left ${wide ? "aspect-video w-[22rem]" : "aspect-[3/4] w-48"}`}
    >
      <img src={t.image} alt={t.title} loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-background/95 via-background/20 to-transparent p-4">
        <div className="font-display text-lg font-bold leading-tight">{t.title}</div>
        <div className="text-sm text-muted-foreground">{t.episode ?? `${t.genre} · ${t.language} · ${t.minutes}m`}</div>
        {t.progress && (
          <div className="mt-3 h-1 w-full rounded-full bg-foreground/25">
            <div className="h-full rounded-full bg-primary" style={{ width: `${t.progress * 100}%` }} />
          </div>
        )}
      </div>
    </button>
  );
}
