import { Link, useRouterState } from "@tanstack/react-router";
import { forwardRef, useEffect, useState, type ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";
import { useStore, usage, LOW_THRESHOLD, fmt } from "@/lib/store";
import { AlertTriangle, Film, Home, Search, Sparkles, HardDrive, Settings, X } from "lucide-react";

type V = "primary" | "secondary" | "ghost" | "danger";
const variants: Record<V, string> = {
  primary: "bg-primary text-primary-foreground",
  secondary: "bg-secondary text-secondary-foreground",
  ghost: "bg-transparent text-foreground border border-border",
  danger: "bg-destructive text-destructive-foreground",
};

export const TvButton = forwardRef<HTMLButtonElement, ButtonHTMLAttributes<HTMLButtonElement> & { variant?: V }>(
  ({ variant = "secondary", className, ...p }, ref) => (
    <button
      ref={ref}
      data-focusable
      className={cn(
        "tv-focus inline-flex items-center justify-center gap-2 rounded-xl px-6 py-3.5 text-lg font-semibold disabled:opacity-40",
        variants[variant],
        className,
      )}
      {...p}
    />
  ),
);
TvButton.displayName = "TvButton";

const NAV = [
  { to: "/", label: "Home", icon: Home },
  { to: "/discover", label: "Find", icon: Search },
  { to: "/recap/night-signal", label: "Story Recap", icon: Sparkles },
  { to: "/storage", label: "Storage", icon: HardDrive },
] as const;

function Clock() {
  const [now, setNow] = useState<string>("");
  useEffect(() => {
    const f = () => setNow(new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }));
    f();
    const id = setInterval(f, 30000);
    return () => clearInterval(id);
  }, []);
  return <span className="tabular-nums">{now}</span>;
}

export function TopNav() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  return (
    <header className="nav-fade fixed inset-x-0 top-0 z-20 flex items-center gap-8 px-14 py-6">
      <div className="flex h-11 w-11 items-center justify-center rounded-full bg-accent font-display text-lg font-bold text-accent-foreground">V</div>
      <nav className="flex gap-1">
        {NAV.map((n) => {
          const active = n.to === "/" ? path === "/" : path.startsWith(n.to.split("/").slice(0, 2).join("/"));
          const Icon = n.icon;
          return (
            <Link
              key={n.to}
              to={n.to as "/"}
              data-focusable
              className={cn(
                "nav-focus flex items-center gap-2 rounded-full px-5 py-2.5 text-lg font-medium",
                active ? "text-foreground" : "text-muted-foreground",
              )}
            >
              <Icon className="h-5 w-5" />
              <span>{n.label}</span>
              {active && <span className="ml-1 h-1.5 w-1.5 rounded-full bg-primary" />}
            </Link>
          );
        })}
      </nav>
      <div className="ml-auto flex items-center gap-5 text-lg text-muted-foreground">
        <Settings className="h-6 w-6" />
        <Clock />
        <div className="flex items-center gap-1.5 font-display font-bold text-foreground">
          <Film className="h-6 w-6 text-primary" /> Cine<span className="text-primary">mate</span>
        </div>
      </div>
    </header>
  );
}

export function LowStorageBanner() {
  const u = useStore(usage);
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [hidden, setHidden] = useState(true);
  useEffect(() => {
    const id = setTimeout(() => setHidden(false), 4000);
    return () => clearTimeout(id);
  }, []);
  if (hidden || u.freePct >= LOW_THRESHOLD || path === "/storage") return null;
  return (
    <div className="glass fixed bottom-8 left-8 z-30 flex max-w-xl items-center gap-4 rounded-2xl px-6 py-4 shadow-2xl">
      <AlertTriangle className="h-7 w-7 text-warning" />
      <div className="flex-1">
        <div className="text-lg font-semibold">Storage almost full</div>
        <div className="text-muted-foreground">
          Only {fmt(u.free)} left ({Math.round(u.freePct * 100)}%). Downloads and updates may fail.
        </div>
      </div>
      <Link to="/storage" data-focusable className="tv-focus rounded-xl bg-warning px-5 py-3 font-semibold text-primary-foreground">
        Manage
      </Link>
      <button data-focusable onClick={() => setHidden(true)} aria-label="Dismiss" className="tv-focus rounded-full p-2 text-muted-foreground">
        <X className="h-5 w-5" />
      </button>
    </div>
  );
}
