import { useEffect, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Mic, X, Send, Sparkles, Volume2, VolumeX } from "lucide-react";
import { parseIntent } from "@/lib/intent";
import { TvButton } from "./tv";
import { speakSoft } from "@/lib/voice";

type Msg = { from: "you" | "ai"; text: string };
const SAMPLES = [
  "How much storage do I have left?",
  "Clean up my storage",
  "Find me a comedy under 30 minutes",
  "Suggest something in Tamil",
  "Show me something shorter",
  "What happened in Night Signal so far?",
  "Summarise Inception",
  "Tell me about Ghost Hours",
];

export function Assistant() {
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const [listening, setListening] = useState(false);
  const [text, setText] = useState("");
  const [tts, setTts] = useState(true);
  const [msgs, setMsgs] = useState<Msg[]>([{ from: "ai", text: "Hi! Ask me about storage, what to watch, or summarise any movie." }]);
  const ctx = useRef<string | undefined>(undefined);
  const recRef = useRef<any>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const endRef = useRef<HTMLDivElement>(null);

  // "M" key or holding Enter on mic simulates remote long-press
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.key === "m" || e.key === "M") && document.activeElement?.tagName !== "INPUT") {
        e.preventDefault();
        setOpen(true);
        setTimeout(startListening, 100);
      }
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  });

  useEffect(() => endRef.current?.scrollIntoView({ block: "end" }), [msgs]);

  const run = (q: string) => {
    if (!q.trim()) return;
    const r = parseIntent(q, ctx.current);
    if (r.context) ctx.current = r.context;
    setMsgs((m) => [...m, { from: "you", text: q }, { from: "ai", text: r.reply }]);
    setText("");
    if (tts) speakSoft(r.reply);
    if (r.to) setTimeout(() => nav({ to: r.to!.path as any, params: r.to!.params as any }), 700);
  };

  function startListening() {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      setMsgs((m) => [...m, { from: "ai", text: "Mic isn't available here — type or pick a sample command." }]);
      inputRef.current?.focus();
      return;
    }
    const rec = new SR();
    rec.lang = "en-IN";
    rec.interimResults = true;
    rec.onresult = (e: any) => {
      const t = Array.from(e.results).map((r: any) => r[0].transcript).join("");
      setText(t);
      if (e.results[e.results.length - 1].isFinal) run(t);
    };
    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);
    recRef.current = rec;
    setListening(true);
    rec.start();
  }

  return (
    <>
      <button
        data-focusable
        onClick={() => setOpen((o) => !o)}
        aria-label="Open voice assistant"
        className="tv-focus fixed bottom-8 right-8 z-40 flex h-20 w-20 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-2xl"
      >
        <Mic className="h-9 w-9" />
      </button>

      {open && (
        <div data-nav-scope className="glass fixed bottom-32 right-8 z-50 flex max-h-[75vh] w-[520px] flex-col rounded-3xl p-6 shadow-2xl">
          <div className="mb-4 flex items-center gap-3">
            <Sparkles className="h-6 w-6 text-primary" />
            <h3 className="flex-1 text-2xl font-semibold">Cinemate Assistant</h3>
            <button data-focusable className="tv-focus rounded-full p-2" onClick={() => setTts((v) => !v)} aria-label="Toggle voice">
              {tts ? <Volume2 /> : <VolumeX />}
            </button>
            <button data-focusable className="tv-focus rounded-full p-2" onClick={() => setOpen(false)} aria-label="Close">
              <X />
            </button>
          </div>

          <div className="mb-4 flex-1 space-y-3 overflow-y-auto pr-1">
            {msgs.map((m, i) => (
              <div key={i} className={m.from === "you" ? "text-right" : ""}>
                <span className="mb-1 block text-xs uppercase tracking-widest text-muted-foreground">{m.from === "you" ? "You said" : "Cinemate"}</span>
                <span className={`inline-block rounded-2xl px-4 py-2.5 text-lg ${m.from === "you" ? "bg-secondary" : "bg-card"}`}>{m.text}</span>
              </div>
            ))}
            <div ref={endRef} />
          </div>

          {listening && (
            <div className="mb-3 flex h-12 items-center justify-center gap-1.5">
              {Array.from({ length: 14 }).map((_, i) => (
                <span key={i} className="wave-bar h-10 w-1.5 rounded-full bg-primary" style={{ animationDelay: `${(i % 7) * 0.1}s` }} />
              ))}
            </div>
          )}

          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              run(text);
            }}
          >
            <TvButton type="button" variant={listening ? "danger" : "primary"} className="px-4" onClick={() => (listening ? recRef.current?.stop() : startListening())} aria-label="Speak">
              <Mic />
            </TvButton>
            <input
              ref={inputRef}
              data-focusable
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={listening ? "Listening…" : "Type a command"}
              className="tv-focus min-w-0 flex-1 rounded-xl bg-input px-4 text-lg"
            />
            <TvButton type="submit" className="px-4" aria-label="Send">
              <Send />
            </TvButton>
          </form>
          <div className="mt-4 flex flex-wrap gap-2">
            {SAMPLES.map((s) => (
              <button key={s} data-focusable onClick={() => run(s)} className="tv-focus rounded-full bg-secondary px-3 py-1.5 text-sm">
                {s}
              </button>
            ))}
          </div>
        </div>
      )}
    </>
  );
}
