// Minimal D-pad spatial navigation: arrow keys move focus to the nearest
// focusable element in that direction.
const SEL = "[data-focusable]:not([disabled])";

export function installSpatialNav() {
  const onKey = (e: KeyboardEvent) => {
    const dirs: Record<string, [number, number]> = { ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0] };
    const d = dirs[e.key];
    const active = document.activeElement as HTMLElement | null;
    if (active && (active.tagName === "INPUT" || active.tagName === "TEXTAREA") && (e.key === "ArrowLeft" || e.key === "ArrowRight")) return;
    if (!d) return;
    // Scope to topmost modal if present
    const scopes = document.querySelectorAll<HTMLElement>("[data-nav-scope]");
    const root: ParentNode = scopes[scopes.length - 1] ?? document;
    const els = Array.from(root.querySelectorAll<HTMLElement>(SEL)).filter((el) => el.offsetParent !== null);
    if (!els.length) return;
    e.preventDefault();
    if (!active || !els.includes(active)) {
      els[0]!.focus();
      return;
    }
    const a = active.getBoundingClientRect();
    const ac = { x: a.left + a.width / 2, y: a.top + a.height / 2 };
    let best: HTMLElement | null = null;
    let bestScore = Infinity;
    for (const el of els) {
      if (el === active) continue;
      const r = el.getBoundingClientRect();
      const c = { x: r.left + r.width / 2, y: r.top + r.height / 2 };
      const dx = c.x - ac.x;
      const dy = c.y - ac.y;
      const along = dx * d[0] + dy * d[1];
      if (along <= 4) continue;
      const across = Math.abs(dx * d[1] + dy * d[0]);
      const score = along + across * 2.5;
      if (score < bestScore) {
        bestScore = score;
        best = el;
      }
    }
    if (best) {
      best.focus();
      best.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" });
    }
  };
  window.addEventListener("keydown", onKey);
  return () => window.removeEventListener("keydown", onKey);
}
