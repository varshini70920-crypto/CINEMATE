import nightSignal from "@/assets/night-signal.jpg";
import monsoonCafe from "@/assets/monsoon-cafe.jpg";
import orbit9 from "@/assets/orbit-9.jpg";
import laughLane from "@/assets/laugh-lane.jpg";
import kadhalKitchen from "@/assets/kadhal-kitchen.jpg";
import tinyFixes from "@/assets/tiny-fixes.jpg";
import deepBlue from "@/assets/deep-blue.jpg";
import theHeist from "@/assets/the-heist.jpg";
import shortStack from "@/assets/short-stack.jpg";
import ghostHours from "@/assets/ghost-hours.jpg";
import vettai from "@/assets/vettai.jpg";
import labRats from "@/assets/lab-rats.jpg";

export type AppItem = { id: string; name: string; color: string; letter: string; appGB: number; cacheGB: number; lastOpenedDays: number };

export const APPS: AppItem[] = [
  { id: "netflix", name: "Netflix", color: "oklch(0.55 0.22 27)", letter: "N", appGB: 0.9, cacheGB: 0.6, lastOpenedDays: 1 },
  { id: "prime", name: "Prime Video", color: "oklch(0.6 0.15 230)", letter: "P", appGB: 0.8, cacheGB: 0.5, lastOpenedDays: 0 },
  { id: "hotstar", name: "Hotstar", color: "oklch(0.45 0.15 260)", letter: "H", appGB: 0.7, cacheGB: 0.45, lastOpenedDays: 3 },
  { id: "youtube", name: "YouTube", color: "oklch(0.6 0.24 25)", letter: "▶", appGB: 0.5, cacheGB: 0.7, lastOpenedDays: 0 },
  { id: "game", name: "Asphalt Racer", color: "oklch(0.65 0.18 60)", letter: "A", appGB: 1.6, cacheGB: 0.3, lastOpenedDays: 64 },
  { id: "zee5", name: "ZEE5", color: "oklch(0.5 0.2 320)", letter: "Z", appGB: 0.6, cacheGB: 0.25, lastOpenedDays: 41 },
  { id: "spotify", name: "Spotify", color: "oklch(0.65 0.19 150)", letter: "S", appGB: 0.4, cacheGB: 0.35, lastOpenedDays: 6 },
  { id: "fitness", name: "FitTV", color: "oklch(0.7 0.15 190)", letter: "F", appGB: 0.5, cacheGB: 0.1, lastOpenedDays: 92 },
];

export type Character = { name: string; role: string; hue: number };
export type Title = {
  id: string;
  title: string;
  type: "Movie" | "Show";
  genre: string;
  language: string;
  minutes: number;
  hue: number;
  year: number;
  image: string;
  blurb?: string;
  progress?: number; // 0..1
  episode?: string;
  timestamp?: string;
  recap?: string[];
  scenes?: string[];
  characters?: Character[];
};

export const TITLES: Title[] = [
  {
    id: "night-signal", title: "Night Signal", type: "Show", genre: "Thriller", language: "English", minutes: 48, hue: 250, year: 2025, image: nightSignal,
    progress: 0.62, episode: "S1 · E4 — The Static Room", timestamp: "29:46 / 48:00",
    recap: [
      "Previously on Night Signal…",
      "Detective Alex Rowe traced the mysterious late-night radio broadcasts to an abandoned relay tower outside the city.",
      "Inside, she found a list of names — including her missing brother's — scrawled on the wall.",
      "Her partner Sam urged her to report it, but Alex chose to keep the discovery quiet.",
      "As you left off, Alex had just tuned into the frequency herself and heard a familiar voice.",
    ],
    scenes: ["Radio crackles in an empty diner", "Alex drives to the relay tower", "The wall of names", "Argument with Sam", "Alex tunes the frequency"],
    characters: [
      { name: "Alex Rowe", role: "The detective investigating the broadcasts", hue: 250 },
      { name: "Sam Ortiz", role: "Her cautious, by-the-book partner", hue: 160 },
      { name: "Marla Keen", role: "Radio host who first reported the signal", hue: 40 },
      { name: "Danny Rowe", role: "Alex's brother, missing for two years", hue: 320 },
    ],
  },
  {
    id: "monsoon-cafe", title: "Monsoon Café", type: "Movie", genre: "Romance", language: "Tamil", minutes: 132, hue: 160, year: 2024, image: monsoonCafe,
    progress: 0.38, episode: "Chapter 2 — First Rain", timestamp: "50:10 / 2:12:00",
    recap: [
      "Previously in Monsoon Café…",
      "Meera returned to Chennai to save her late grandmother's struggling café.",
      "She clashed with Arjun, a food critic whose harsh review nearly closed the place.",
      "A sudden downpour trapped them inside together, and they reluctantly cooked a meal side by side.",
      "You left off as Arjun admitted he never actually tasted the food he reviewed.",
    ],
    scenes: ["Meera arrives at the station", "The dusty café", "Arjun's review", "Rain traps them", "Cooking together"],
    characters: [
      { name: "Meera", role: "Determined new owner of the café", hue: 160 },
      { name: "Arjun", role: "The critic with a secret", hue: 30 },
      { name: "Paati", role: "Grandmother seen in flashbacks", hue: 80 },
    ],
  },
  {
    id: "orbit-9", title: "Orbit 9", type: "Show", genre: "Sci-Fi", language: "English", minutes: 42, hue: 200, year: 2026, image: orbit9,
    progress: 0.81, episode: "S2 · E7 — Dead Reckoning", timestamp: "34:02 / 42:00",
    recap: [
      "Previously on Orbit 9…",
      "The station lost contact with Earth after a solar storm fried the main array.",
      "Commander Ito rationed power while engineer Bea hunted for the source of a hull breach.",
      "Bea discovered the breach wasn't an accident — someone had loosened the panel from inside.",
    ],
    scenes: ["Solar storm hits", "Blackout on deck", "Rationing meeting", "Bea finds the panel"],
    characters: [
      { name: "Cmdr. Ito", role: "Leader keeping the crew calm", hue: 200 },
      { name: "Bea Lund", role: "Engineer who found the sabotage", hue: 20 },
      { name: "Kofi", role: "Medic with a mysterious past", hue: 120 },
    ],
  },
  { id: "laugh-lane", title: "Laugh Lane", type: "Show", genre: "Comedy", language: "English", minutes: 22, hue: 60, year: 2025, image: laughLane },
  { id: "chennai-express-2", title: "Kadhal Kitchen", type: "Movie", genre: "Comedy", language: "Tamil", minutes: 118, hue: 30, year: 2023, image: kadhalKitchen },
  { id: "tiny-fixes", title: "Tiny Fixes", type: "Show", genre: "Comedy", language: "Hindi", minutes: 25, hue: 100, year: 2026, image: tinyFixes },
  { id: "deep-blue", title: "Deep Blue Below", type: "Movie", genre: "Documentary", language: "English", minutes: 88, hue: 220, year: 2024, image: deepBlue },
  { id: "the-heist", title: "The Last Heist", type: "Movie", genre: "Action", language: "Hindi", minutes: 141, hue: 10, year: 2025, image: theHeist },
  { id: "short-stack", title: "Short Stack", type: "Show", genre: "Comedy", language: "Tamil", minutes: 18, hue: 340, year: 2026, image: shortStack },
  { id: "ghost-hours", title: "Ghost Hours", type: "Movie", genre: "Horror", language: "English", minutes: 97, hue: 290, year: 2024, image: ghostHours },
  { id: "vettai", title: "Vettai Raja", type: "Movie", genre: "Action", language: "Tamil", minutes: 150, hue: 0, year: 2025, image: vettai },
  { id: "lab-rats", title: "Lab Rats", type: "Show", genre: "Sci-Fi", language: "English", minutes: 28, hue: 180, year: 2023, image: labRats },
];

export const findTitle = (q: string) => {
  const n = q.toLowerCase();
  return TITLES.find((t) => n.includes(t.title.toLowerCase()) || n.includes(t.id));
};
export const slugify = (s: string) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
export const unslug = (s: string) => decodeURIComponent(s).replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

export const CONTINUE = TITLES.filter((t) => t.progress);
export const LANGUAGES = ["English", "Tamil", "Hindi"];
export const GENRES = ["Comedy", "Thriller", "Romance", "Sci-Fi", "Action", "Horror", "Documentary"];

export const poster = (hue: number) =>
  `linear-gradient(135deg, oklch(0.45 0.14 ${hue}) 0%, oklch(0.22 0.08 ${hue + 40}) 70%, oklch(0.14 0.03 ${hue + 60}) 100%)`;
