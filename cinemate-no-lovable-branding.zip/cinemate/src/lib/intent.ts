import { GENRES, LANGUAGES, CONTINUE, findTitle, slugify } from "./data";
import { store, usage, suggestions, fmt, type Filters } from "./store";

export type IntentResult = { reply: string; to?: { path: string; params?: Record<string, string> }; context?: "discover" | "storage" | "recap" };

export function parseIntent(raw: string, lastContext?: string): IntentResult {
  const q = raw.toLowerCase().trim();
  const s = store.get();

  // Follow-ups on Discover
  if (lastContext === "discover" && /(shorter|longer|another|different|instead|only|movie|show|series)/.test(q) && !/storage|recap/.test(q)) {
    const f: Filters = { ...s.filters, ...extractFilters(q) };
    if (/shorter/.test(q)) f.maxMinutes = Math.max(15, Math.round((f.maxMinutes ?? 120) / 2));
    if (/longer/.test(q)) f.maxMinutes = undefined;
    store.setFilters(f);
    return { reply: `Sure — updated: ${describe(f)}. Here's what matches.`, to: { path: "/discover" }, context: "discover" };
  }

  if (/storage|space|clean|free up|cache|uninstall|memory/.test(q)) {
    const u = usage(s);
    const sug = suggestions(s);
    const potential = sug.reduce((n, x) => n + x.gb, 0);
    const reply = /clean|free up|clear/.test(q)
      ? `I found ${sug.length} items you can remove, freeing about ${fmt(potential)}. Review them and press "Clear all suggested".`
      : `You have ${fmt(u.free)} free of 16 GB. Want me to clear app cache to free up about ${fmt(potential)} more?`;
    return { reply, to: { path: "/storage" }, context: "storage" };
  }

  if (/recap|what happened|so far|previously|remind|summar|story of|plot of|what is .* about|tell me about/.test(q)) {
    const local = findTitle(q);
    const m = q.match(/(?:summari[sz]e|summary of|recap of|recap|what happened in|story of|plot of|tell me about|remind me of|what is)\s+(?:the\s+)?(?:movie\s+|film\s+|show\s+|series\s+)?(.+?)(?:\s+(?:so far|about|movie|film|for me))?[?.!]*$/);
    const name = m?.[1]?.trim();
    if (local) {
      return {
        reply: local.progress
          ? `Here's a spoiler-safe recap of ${local.title}, up to ${local.timestamp?.split(" /")[0]}.`
          : `Here's the story of ${local.title}.`,
        to: { path: "/recap/$id", params: { id: local.id } },
        context: "recap",
      };
    }
    if (name && name.length > 1 && !/^(it|this|that|my show)$/.test(name)) {
      return { reply: `Sure — summarising ${name} for you now.`, to: { path: "/recap/$id", params: { id: slugify(name) } }, context: "recap" };
    }
    const t = CONTINUE[0]!;
    return { reply: `Here's a spoiler-safe recap of ${t.title}.`, to: { path: "/recap/$id", params: { id: t.id } }, context: "recap" };
  }

  const f = extractFilters(q);
  if (/find|suggest|show me|watch|recommend|something|comedy|movie|show/.test(q) || Object.keys(f).length) {
    store.setFilters(f);
    return { reply: `Here are some picks — ${describe(f)}.`, to: { path: "/discover" }, context: "discover" };
  }

  return { reply: "I can help you manage storage, find something to watch, or recap a show — what would you like?" };
}

function extractFilters(q: string): Filters {
  const f: Filters = {};
  const lang = LANGUAGES.find((l) => q.includes(l.toLowerCase()));
  if (lang) f.language = lang;
  const genre = GENRES.find((g) => q.includes(g.toLowerCase().replace("-", "")) || q.includes(g.toLowerCase()));
  if (genre) f.genre = genre;
  if (/funny|laugh/.test(q)) f.genre = "Comedy";
  if (/scary/.test(q)) f.genre = "Horror";
  const m = q.match(/(under|less than|within|below)\s+(\d+)\s*(min|minute|hour|hr)/);
  if (m) f.maxMinutes = Number(m[2]) * (m[3]!.startsWith("h") ? 60 : 1);
  if (/\b(movie|film)s?\b/.test(q)) f.type = "Movie";
  if (/\b(show|series|episode)s?\b/.test(q) && !/show me/.test(q.replace(/show me .*(show|series)/, "x"))) f.type = "Show";
  return f;
}

export function describe(f: Filters) {
  const parts = [f.genre, f.language, f.type?.toLowerCase() + "s", f.maxMinutes ? `under ${f.maxMinutes} min` : ""].filter(
    (x) => x && x !== "undefineds",
  );
  return parts.length ? parts.join(" · ") : "everything";
}
