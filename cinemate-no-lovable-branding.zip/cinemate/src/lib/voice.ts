// Soft, calm text-to-speech using the gentlest voice the device offers.
const PREFERRED = [
  /natural/i, // Edge/Windows neural voices (e.g. "Microsoft Aria Online (Natural)")
  /google uk english female/i,
  /samantha|ava|allison|serena|karen|moira|tessa/i,
  /female|aria|jenny|zira|heera|veena/i,
  /google us english/i,
];

let cached: SpeechSynthesisVoice | null = null;

function pickVoice(): SpeechSynthesisVoice | null {
  if (cached) return cached;
  const voices = speechSynthesis.getVoices().filter((v) => v.lang.toLowerCase().startsWith("en"));
  for (const re of PREFERRED) {
    const v = voices.find((x) => re.test(x.name));
    if (v) return (cached = v);
  }
  return voices[0] ?? null;
}

if (typeof window !== "undefined" && "speechSynthesis" in window) {
  speechSynthesis.onvoiceschanged = () => {
    cached = null;
    pickVoice();
  };
}

export function speakSoft(text: string) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  // Split into sentences so long text doesn't get cut off and pauses feel natural.
  const parts = text.match(/[^.!?]+[.!?]*/g) ?? [text];
  const voice = pickVoice();
  for (const p of parts) {
    const u = new SpeechSynthesisUtterance(p.trim());
    if (voice) u.voice = voice;
    u.rate = 0.9;
    u.pitch = 1.08;
    u.volume = 0.75;
    speechSynthesis.speak(u);
  }
}

export function stopSpeaking() {
  if (typeof window !== "undefined" && "speechSynthesis" in window) speechSynthesis.cancel();
}
