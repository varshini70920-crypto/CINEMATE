import { useSyncExternalStore } from "react";
import { APPS, type AppItem } from "./data";

export const TOTAL_GB = 16;
export const SYSTEM_GB = 4.8;
export const LOW_THRESHOLD = 0.1;

export type Filters = { language?: string | undefined; genre?: string | undefined; maxMinutes?: number | undefined; type?: "Movie" | "Show" | undefined };

type State = {
  apps: AppItem[];
  tempGB: number;
  filters: Filters;
  freedGB: number;
};

let state: State = { apps: APPS, tempGB: 0.6, filters: {}, freedGB: 0 };
const listeners = new Set<() => void>();
const set = (patch: Partial<State>) => {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
};

export const store = {
  get: () => state,
  subscribe: (l: () => void) => {
    listeners.add(l);
    return () => listeners.delete(l);
  },
  clearCache(id: string) {
    const a = state.apps.find((x) => x.id === id);
    if (!a) return;
    set({ freedGB: state.freedGB + a.cacheGB, apps: state.apps.map((x) => (x.id === id ? { ...x, cacheGB: 0 } : x)) });
  },
  uninstall(id: string) {
    const a = state.apps.find((x) => x.id === id);
    if (!a) return;
    set({ freedGB: state.freedGB + a.appGB + a.cacheGB, apps: state.apps.filter((x) => x.id !== id) });
  },
  clearTemp() {
    set({ freedGB: state.freedGB + state.tempGB, tempGB: 0 });
  },
  clearAllSuggested() {
    const s = suggestions(state);
    let freed = 0;
    let apps = state.apps;
    for (const x of s) {
      if (x.kind === "unused") {
        apps = apps.filter((a) => a.id !== x.appId);
      } else if (x.kind === "cache") {
        apps = apps.map((a) => (a.id === x.appId ? { ...a, cacheGB: 0 } : a));
      }
      freed += x.gb;
    }
    set({ apps, tempGB: 0, freedGB: state.freedGB + freed });
    return freed;
  },
  setFilters(f: Filters) {
    set({ filters: f });
  },
};

export function useStore<T>(sel: (s: State) => T): T {
  const s = useSyncExternalStore(store.subscribe, store.get, store.get);
  return sel(s);
}

export function usage(s: State) {
  const apps = s.apps.reduce((n, a) => n + a.appGB, 0);
  const cache = s.apps.reduce((n, a) => n + a.cacheGB, 0) + s.tempGB;
  const used = apps + cache + SYSTEM_GB;
  const free = Math.max(0, TOTAL_GB - used);
  return { apps, cache, system: SYSTEM_GB, used, free, freePct: free / TOTAL_GB };
}

export type Suggestion = { id: string; kind: "unused" | "cache" | "temp"; appId?: string; label: string; detail: string; gb: number };

export function suggestions(s: State): Suggestion[] {
  const out: Suggestion[] = [];
  for (const a of s.apps) {
    if (a.lastOpenedDays >= 30)
      out.push({ id: "u-" + a.id, kind: "unused", appId: a.id, label: `Uninstall ${a.name}`, detail: `Not opened in ${a.lastOpenedDays} days`, gb: a.appGB + a.cacheGB });
  }
  for (const a of s.apps) {
    if (a.lastOpenedDays < 30 && a.cacheGB >= 0.2)
      out.push({ id: "c-" + a.id, kind: "cache", appId: a.id, label: `Clear ${a.name} cache`, detail: "Cached thumbnails & stream buffers", gb: a.cacheGB });
  }
  if (s.tempGB > 0) out.push({ id: "temp", kind: "temp", label: "Leftover temp files", detail: "From interrupted downloads & streaming", gb: s.tempGB });
  return out;
}

export const fmt = (gb: number) => (gb < 1 ? `${Math.round(gb * 1024)} MB` : `${gb.toFixed(1)} GB`);
