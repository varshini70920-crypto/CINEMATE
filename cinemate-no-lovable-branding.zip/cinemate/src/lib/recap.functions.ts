import { createServerFn } from "@tanstack/react-start";

export type AiRecap = {
  found: boolean;
  title: string;
  year: string;
  genre: string;
  tagline: string;
  summary: string[];
  scenes: string[];
  characters: { name: string; role: string }[];
};

const schema = {
  type: "object",
  additionalProperties: false,
  required: ["found", "title", "year", "genre", "tagline", "summary", "scenes", "characters"],
  properties: {
    found: { type: "boolean", description: "false if you do not know this movie/show" },
    title: { type: "string" },
    year: { type: "string" },
    genre: { type: "string" },
    tagline: { type: "string" },
    summary: { type: "array", items: { type: "string" }, description: "4-6 short paragraphs" },
    scenes: { type: "array", items: { type: "string" }, description: "5 key moments, short phrases" },
    characters: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["name", "role"],
        properties: { name: { type: "string" }, role: { type: "string" } },
      },
    },
  },
};

export const summarizeTitle = createServerFn({ method: "POST" })
  .inputValidator((d: { name: string; catalog?: boolean | undefined; context?: string | undefined; leftOff?: string | undefined }) => {
    const name = String(d?.name ?? "").trim().slice(0, 120);
    if (!name) throw new Error("Please give a movie or show name.");
    return { name, catalog: !!d.catalog, context: d.context?.slice(0, 600), leftOff: d.leftOff?.slice(0, 80) };
  })
  .handler(async ({ data }): Promise<AiRecap> => {
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) throw new Error("AI summaries aren't set up yet.");
    const prompt = [
      `Summarise the movie or TV show "${data.name}" for a TV viewer.`,
      data.context ? `Known details: ${data.context}` : "",
      data.leftOff
        ? `The viewer stopped at ${data.leftOff}; keep it spoiler-safe up to that point.`
        : "Give the setup and main story arc, but do not reveal the ending or twists.",
      data.catalog
        ? "This is an original title in our streaming catalogue. Write an original, believable synopsis that fits the details given, and set found=true."
        : "",
      data.catalog
        ? "Write in simple, warm English. Invent named characters and key moments; never say you lack information."
        : "Write in simple, warm English. If you genuinely don't know the title, set found=false and leave other fields brief.",
    ].join("\n");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "openai/gpt-6-astra",
        reasoning: { effort: "low" },
        input: [{ role: "user", content: prompt }],
        text: { format: { type: "json_schema", name: "recap", strict: true, schema } },
      }),
    });
    if (res.status === 429) throw new Error("Too many requests right now — try again in a moment.");
    if (res.status === 402) throw new Error("AI credits have run out. Add credits to keep using summaries.");
    if (!res.ok) throw new Error(`Couldn't get a summary (error ${res.status}).`);
    const json: any = await res.json();
    let text: string = json.output_text ?? "";
    if (!text && Array.isArray(json.output)) {
      for (const o of json.output)
        for (const c of o.content ?? []) if (c.type === "output_text") text += c.text;
    }
    if (!text) throw new Error("The AI didn't return a summary. Try again.");
    return JSON.parse(text) as AiRecap;
  });
